package Animation;

public interface IAnimation { //Componente do grupo Clube do Hardware
    public void story(String[] falas, String[] personagem);
    public void setWindowName(String name);
    public void setTempo(String v);
    public void setPacientName(String pacName);
    public void setDocName(String docName);
}