/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JFrame;

import Animation.*;
import src.classes.*;
import src.interfaces.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;


public class Principal extends javax.swing.JFrame {
    //Variaveis:
    IDataSet dataset = null;
    int Diagnosticados = 0;
    int Acertos = 0;
    Chat JChat;
    @SuppressWarnings("OverridableMethodCallInConstructor")
    public Principal() {
        initComponents();
        setLocationRelativeTo(null);
        btn_Dialogo.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalFrame1 = new javax.swing.JInternalFrame();
        jInternalFrame2 = new javax.swing.JInternalFrame();
        btn_CSV = new javax.swing.JButton();
        btn_Carregar = new javax.swing.JButton();
        btn_Diagnostico = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_Saida = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_NomeDoutor = new javax.swing.JTextField();
        txt_NomePaciente = new javax.swing.JTextField();
        btn_Resetar = new javax.swing.JButton();
        btn_Fechar = new javax.swing.JButton();
        btn_Salvar = new javax.swing.JButton();
        txt_CSV = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lbl_Diagnosticados = new javax.swing.JLabel();
        lbl_Acertos = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btn_Dialogo = new javax.swing.JButton();

        jInternalFrame1.setVisible(true);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jInternalFrame2.setVisible(true);

        javax.swing.GroupLayout jInternalFrame2Layout = new javax.swing.GroupLayout(jInternalFrame2.getContentPane());
        jInternalFrame2.getContentPane().setLayout(jInternalFrame2Layout);
        jInternalFrame2Layout.setHorizontalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jInternalFrame2Layout.setVerticalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ZombieHealth");
        setResizable(false);

        btn_CSV.setText("Selecionar");
        btn_CSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CSVActionPerformed(evt);
            }
        });

        btn_Carregar.setText("Carregar");
        btn_Carregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CarregarActionPerformed(evt);
            }
        });

        btn_Diagnostico.setText("Fazer Diagnóstico");
        btn_Diagnostico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DiagnosticoActionPerformed(evt);
            }
        });

        txt_Saida.setEditable(false);
        txt_Saida.setColumns(20);
        txt_Saida.setRows(5);
        jScrollPane1.setViewportView(txt_Saida);

        jLabel1.setText("Nome do Doutor:");

        jLabel2.setText("Nome do Paciente:");

        btn_Resetar.setText("Reset");
        btn_Resetar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ResetarActionPerformed(evt);
            }
        });

        btn_Fechar.setText("Sair");
        btn_Fechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_FecharActionPerformed(evt);
            }
        });

        btn_Salvar.setText("Salvar Relatório");
        btn_Salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SalvarActionPerformed(evt);
            }
        });

        txt_CSV.setEditable(false);
        txt_CSV.setText("Selecione o Arquivo CSV");

        jLabel3.setText("Pacientes diagnosticados:");

        lbl_Diagnosticados.setText("-");

        lbl_Acertos.setText("-");

        jLabel4.setText("Percentual de acertos:");

        btn_Dialogo.setText("Ver Dialogo");
        btn_Dialogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DialogoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btn_Resetar, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_Salvar)
                        .addGap(116, 116, 116)
                        .addComponent(btn_Fechar, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txt_NomePaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lbl_Diagnosticados, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(txt_NomeDoutor, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_Diagnostico, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_Dialogo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(txt_CSV)
                        .addGap(18, 18, 18)
                        .addComponent(btn_CSV, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_Carregar))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_Acertos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(293, 293, 293)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_CSV)
                    .addComponent(btn_Carregar)
                    .addComponent(txt_CSV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_NomeDoutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Diagnostico))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_NomePaciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Dialogo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_Diagnosticados))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_Acertos)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Resetar)
                    .addComponent(btn_Fechar)
                    .addComponent(btn_Salvar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_CSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CSVActionPerformed
        JFileChooser AbrirCSV = new JFileChooser();
        AbrirCSV.setDialogTitle("Selecione a CSV");
        AbrirCSV.setFileSelectionMode(JFileChooser.FILES_ONLY);
        
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Arquivo CSV","csv");
        
        AbrirCSV.setFileFilter(filter);
        int retorno = AbrirCSV.showOpenDialog(this);
        
        if(retorno == JFileChooser.APPROVE_OPTION){
            File file = AbrirCSV.getSelectedFile();
            txt_CSV.setText(file.getPath());
        }
    }//GEN-LAST:event_btn_CSVActionPerformed
    
    private void btn_CarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CarregarActionPerformed
        try{
            this.dataset = new DataSetComponent();
            IDiseases a = new Diseases();
            this.dataset.setDataSource(txt_CSV.getText());

            StringWriter sw = new StringWriter();
            PrintWriter Saida = new PrintWriter(sw);

            Saida.println("As Doenças e suas respectivas ocorencias são:");
            ArrayList<String> Doencas = a.ListDiseases(dataset.requestInstances());
            String Ocorrencia[][] = a.PercentualDeOcorrencias(dataset.requestInstances());

            for(int i = 0;i<Doencas.size();i++){
                Saida.println(i+1 +") " + Doencas.get(i) + ", ocorrencia: " + Ocorrencia[i][1]);
            }
            txt_Saida.append(sw.toString());
        }catch(RuntimeException e){
            JOptionPane.showMessageDialog(rootPane,"Diretório Invalido!","Erro",JOptionPane.ERROR_MESSAGE);

        }
    }//GEN-LAST:event_btn_CarregarActionPerformed
    
    private void btn_DiagnosticoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DiagnosticoActionPerformed
        IDoctor cDoctor = new Doutor();
        try{
            //Diagnostico
            IPatient aPatient = new Patient();
            StringWriter sw = new StringWriter();
            PrintWriter Saida = new PrintWriter(sw);
            IDiseases a = new Diseases();
            String Diagnostico;
            
            cDoctor.connect(aPatient);
            aPatient.connect(dataset);
            cDoctor.connect(dataset);
            
            cDoctor.startInterview();

            //Relatório
            Saida.println("------------------------------------------------------------------------");
            Saida.println("Nome do Paciente: " + txt_NomePaciente.getText());
            Saida.println("Nome do Doutor: " + txt_NomeDoutor.getText());

            Diagnostico = a.DiagnosticoMaisProvavel(dataset.requestInstances(), a.LimparArray(cDoctor.getDiagnosis()));

            boolean result = aPatient.finalAnswer(Diagnostico);
            if(result)
                Acertos++;
            Saida.println("Diagnostico: " + Diagnostico);
            Saida.println("Final Answer: O Doutor "+ ((result) ? "Acertou!" : "Errou!"));
            Saida.println("------------------------------------------------------------------------");
            txt_Saida.append(sw.toString());

            //Conversa
            ArrayList<String> Conversa = cDoctor.getConversa();
            ArrayList<String> Personagens = cDoctor.getPersonagens();
            
            Conversa.add("Provavelmente voce está com " + Diagnostico);
            Conversa.add(((result) ? "Voce esta correto =)" : "Voce errou =("));

            Personagens.add("doctor");
            Personagens.add("pacient");
            
            String[] ConversaVet = new String[Conversa.size()];
            ConversaVet = Conversa.toArray(ConversaVet);
            
            String[] PersonagensVet = new String[Personagens.size()];
            PersonagensVet = Personagens.toArray(PersonagensVet);
            
            //Animation
            IAnimation teste = new Animation();
            
            teste.setWindowName("Dialogo");
            teste.setTempo("slow");
            teste.setDocName(txt_NomeDoutor.getText());
            teste.setPacientName(txt_NomePaciente.getText());
            teste.story(ConversaVet,PersonagensVet);
            
            //Diagnosticados e Acertos
            lbl_Diagnosticados.setText(String.valueOf(++Diagnosticados));
            if(Acertos != 0)
                lbl_Acertos.setText(String.valueOf(((100*(float)Acertos/(float)Diagnosticados)))+"%");
            
            //Ver Dialogo
            btn_Dialogo.setEnabled(true);
            JChat = new Chat();
            for(int i = 0;i<Conversa.size();i++){
               JChat.appendTxtChat("[Doutor " + txt_NomeDoutor.getText()+ "]"+Conversa.get(i));
               i++;
               JChat.appendTxtChat("[Paciente " + txt_NomePaciente.getText()+ "]"+Conversa.get(i));
               JChat.appendTxtChat("");
            }
        }catch(NullPointerException e){
            JOptionPane.showMessageDialog(rootPane,"CSV não carregada!","Erro",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btn_DiagnosticoActionPerformed

    private void btn_ResetarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ResetarActionPerformed
       //Botão de Reset
       txt_CSV.setText("");
       txt_NomeDoutor.setText("");
       txt_NomePaciente.setText("");
       txt_Saida.setText("");
       dataset = null;
       lbl_Acertos.setText("-");
       lbl_Diagnosticados.setText("-");
       Diagnosticados = 0;
       Acertos = 0; 
    }//GEN-LAST:event_btn_ResetarActionPerformed

    private void btn_FecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_FecharActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btn_FecharActionPerformed

    private void btn_SalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SalvarActionPerformed
       JFileChooser SalvarTXT = new JFileChooser();
       SalvarTXT.setFileSelectionMode(JFileChooser.FILES_ONLY);
       FileNameExtensionFilter filter = new FileNameExtensionFilter("Documento de Texto (*.txt)","txt");
       SalvarTXT.setFileFilter(filter);

       int retorno = SalvarTXT.showSaveDialog(this);
       if(retorno == JFileChooser.APPROVE_OPTION){
            File file = SalvarTXT.getSelectedFile();
            FileWriter arquivo;
            try {
                arquivo = new FileWriter(file.getPath()+".txt");
                arquivo.write(txt_Saida.getText());
                arquivo.close();
                JOptionPane.showMessageDialog(rootPane, "Arquivo Salvo!","Concluido",JOptionPane.INFORMATION_MESSAGE);

                
            } catch (IOException erro){
                JOptionPane.showMessageDialog(rootPane, "Não foi possivel salvar o arquivo!","Falha",JOptionPane.ERROR_MESSAGE);
            }           
        }
    }//GEN-LAST:event_btn_SalvarActionPerformed

    private void btn_DialogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DialogoActionPerformed
            JChat.setVisible(true);
    }//GEN-LAST:event_btn_DialogoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_CSV;
    private javax.swing.JButton btn_Carregar;
    private javax.swing.JButton btn_Diagnostico;
    private javax.swing.JButton btn_Dialogo;
    private javax.swing.JButton btn_Fechar;
    private javax.swing.JButton btn_Resetar;
    private javax.swing.JButton btn_Salvar;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JInternalFrame jInternalFrame2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_Acertos;
    private javax.swing.JLabel lbl_Diagnosticados;
    private javax.swing.JTextField txt_CSV;
    private javax.swing.JTextField txt_NomeDoutor;
    private javax.swing.JTextField txt_NomePaciente;
    private javax.swing.JTextArea txt_Saida;
    // End of variables declaration//GEN-END:variables
}
