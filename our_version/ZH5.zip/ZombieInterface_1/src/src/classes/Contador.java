package src.classes;
import src.interfaces.*;

public class Contador implements IContador {

	@Override
	public int melhorPergunta(String[][] sintomas) {
		return 0;
	}

	@Override
	public int[] melhoresPerguntas(String[][] sintomas) {
		int vet[] = {0,1,2,3,4,5,6};
		return vet;
	}

}
