package src.classes;
import java.util.ArrayList;
import java.util.Arrays;
import src.interfaces.* ; 

public class Diseases implements IDiseases{
	
	public ArrayList<String> ListDiseases(String instances[][]){
		ArrayList<String> Diseases = new ArrayList<String>();
		for(int i =0; i<instances.length;i++) {
			if(!Diseases.contains(instances[i][instances[i].length-1])) {
				Diseases.add(instances[i][instances[i].length-1]);
			}
		}
		return Diseases;
	}
	
	public ArrayList<String> LimparArray(ArrayList<String> Array){
		ArrayList<String> Novo = new ArrayList<String>();
		
		for(int i = 0; i< Array.size(); i++)
			if(!Novo.contains(Array.get(i)))
				Novo.add(Array.get(i));
		return Novo;
	}
	
	public ArrayList<String> toArrayList(String Vetor){
		return new ArrayList<String>(Arrays.asList(Vetor));
	}
	
	public double[] PercentualDeElementos(String instances[][],ArrayList<String> Array){
		Array = LimparArray(Array);
		
        double Resultados[] = new double[Array.size()];
        double ocorrencia;
        
        for(int k = 0; k < Array.size(); k++){
            ocorrencia = 0;
            for(int i = 0; i < instances.length;i++){
                    if((Array.get(k)).equals(instances[i][instances[i].length-1]) )
                    	ocorrencia++;
            }	    
            Resultados[k] = ocorrencia/instances.length;
        }
        
        return Resultados;
	}
	
	public String[][] PercentualDeOcorrencias(String instances[][]){
		ArrayList<String> Diseases = this.ListDiseases(instances);
		
		String Matriz[][] = new String[Diseases.size()][2];
		
		double ocorrencia;
        
        for(int k = 0; k < Diseases.size(); k++){
        	Matriz[k][0] = Diseases.get(k);
            ocorrencia = 0;
            for(int i = 0; i < instances.length;i++){
                    if((Diseases.get(k)).equals(instances[i][instances[i].length-1]) )
                    	ocorrencia++;
            }	    
            Matriz[k][1] =  String.valueOf(100 * ocorrencia/instances.length) + "%";
        }
        
        return Matriz;	
	}

	private int Pos_Maior(double Vet[]){
	    double elemento = 0;
	    int pos = 0;
	    for(int i = 0; i < Vet.length; i++){
	    	if(Vet[i] > elemento){
	    		elemento = Vet[i];
	    		pos = i;
	        }
	    }
	    return pos;
	}
		
	public String DiagnosticoMaisProvavel(String instances[][],ArrayList<String> Possiveis_Diagnosticos){
	        String MelhorDiagnostico;
	        double Resultados[];	
	        
	        if(Possiveis_Diagnosticos.size() != 1) {
	        	Resultados = this.PercentualDeElementos(instances, Possiveis_Diagnosticos);
	        	MelhorDiagnostico = Possiveis_Diagnosticos.get(Pos_Maior(Resultados));
	        }
	        
	        else {
	        	MelhorDiagnostico = Possiveis_Diagnosticos.get(0);
	        }
	        
	        return MelhorDiagnostico;
	}
}


