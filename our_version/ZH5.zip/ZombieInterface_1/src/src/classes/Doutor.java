package src.classes;
import src.interfaces.* ;
import java.util.ArrayList;

public class Doutor implements IDoctor {
    private ITableProducer producer;
    private IResponder responder;
    private ArrayList<String>  diagnosis =  null,
                               Conversa = null,
                               Personagens = null;
    @Override
    public void connect(ITableProducer producer) {
        this.producer = producer;
    }
    
    @Override
    public void connect(IResponder responder) {
        this.responder = responder;
    }
    
    @Override
    public ArrayList<String> getDiagnosis(){
    	return diagnosis;
    }
    @Override
    public ArrayList<String> getConversa(){
    	return Conversa;
    }
    @Override
    public ArrayList<String> getPersonagens(){
    	return Personagens;
    }
    @Override
    public void startInterview(){
        String Perguntas[] = {"Voce teve ","Voce se lembra de ter tido ", "Voce sentiu "};
        String FrasesDeNegacao[] = {"Não tive isso." , "Não me recordo de ter tido isso.","Não me recordo de ter tido isso.", "Não." , "Não me lembro.", "Acho que não.", "Não tive esse sintoma.", "Não, ainda bem.","Pelo que me lembro, não."};
        String FrasesDeAfirmacao[] = {"Tive esse problema.", "Lembro de ter sentido isso.", "Sim.", "Tive esse Sintoma.","Me lembro de ter sentido.", "Eu me senti muito mal com isso.", "Sim, não desejo isso pra ninguem.", "Sim, e fiquei muito mal."};  
        
        Conversa = new ArrayList<>();
        Personagens = new ArrayList<>();

	String attributes[] = producer.requestAttributes();
        
        String Instancias[][] = producer.requestInstances();
        String instances[][] =Instancias.clone();
               
        diagnosis = new ArrayList<>();
        boolean diagnostico = false;
        
        IContador Contador = new Contador();
        int MelhoresPerguntas[] = Contador.melhoresPerguntas(instances);
        
        Imatrix_modifiers Modificador = new Matriz_modifier();
        
        instances = Modificador.matrixClean(instances);
        for(int a = 0; a < MelhoresPerguntas.length - 1; a++){
            String Resposta = responder.ask(attributes[MelhoresPerguntas[a]]);
            // Parte da conversa
            Conversa.add(Perguntas[(int)(Math.random() * Perguntas.length -1)] +""+ attributes[a]+ "?");
            Personagens.add("doctor");
            if(Resposta.equals("t"))
               Conversa.add(FrasesDeAfirmacao[(int)(Math.random() * FrasesDeAfirmacao.length -1)]);
            else
               Conversa.add(FrasesDeNegacao[(int)(Math.random() * FrasesDeNegacao.length -1)]);
             Personagens.add("pacient");
            //Percorre as linhas da matriz e remove as linhs que nao sao compativeis com os sintomas do paciente        	
            for(int i = 0; i<instances.length; i++) {
            	if(!Resposta.equalsIgnoreCase(instances[i][MelhoresPerguntas[a]])) {
            		instances = Modificador.deleteLine(instances, i);
            		i--;
            	}
            }      	
            if(instances.length == 1) {
            	diagnosis.add(instances[0][attributes.length - 1]);
            	diagnostico = true;
            	break;
            } 
        }
        if(diagnostico == false) {
            for(int i = 0; i < instances.length; i++){
                diagnosis.add(instances[i][attributes.length - 1]);
            }       
        }
		
	}

	
}
