package src.classes;
import src.interfaces.*;
import JFrame.*;

public class Main {

	public static void main(String[] args) {
		IDataSet dataset = new DataSetComponent();
		dataset.setDataSource("C:\\Users\\Mateus\\eclipse-workspace\\ZombieHealth\\src\\db\\zombie-health-cases500.csv");
		
		IPatient aPatient = new Patient();
		aPatient.connect(dataset);
		
		IDoctor cDoctor = new Doutor();
		cDoctor.connect(dataset);
		cDoctor.connect(aPatient);
		
		cDoctor.startInterview();

		IDiseases a = new Diseases();

		boolean result = aPatient.finalAnswer(a.DiagnosticoMaisProvavel(dataset.requestInstances(), a.LimparArray(cDoctor.getDiagnosis()) ) );
        System.out.println("Result: " + ((result) ? "I am right =)" : "I am wrong =("));
		
		
		
	}

}
