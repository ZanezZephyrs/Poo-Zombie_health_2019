package src.interfaces;

public interface IContador { //Componente do Grupo OS Matitos
	public int melhorPergunta(String[][] sintomas);
	public int[] melhoresPerguntas(String[][] sintomas);
}