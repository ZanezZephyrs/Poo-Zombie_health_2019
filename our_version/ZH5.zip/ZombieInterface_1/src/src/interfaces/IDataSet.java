package src.interfaces;

public interface IDataSet extends IDataSource, ITableProducer {
}