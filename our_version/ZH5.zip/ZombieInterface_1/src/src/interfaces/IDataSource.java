package src.interfaces;

public interface IDataSource {
	  public String getDataSource();
	  public void setDataSource(String dataSource);
	}

