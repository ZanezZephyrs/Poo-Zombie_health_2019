package src.interfaces;

import java.util.ArrayList;

public interface IDiseases {
	public ArrayList<String> ListDiseases(String instances[][]);

	public String[][] PercentualDeOcorrencias(String instances[][]);
	
	public double[] PercentualDeElementos(String instances[][],ArrayList<String> Array);
		
	public ArrayList<String> LimparArray(ArrayList<String> Possiveis_Diagnosticos);
	
	public ArrayList<String> toArrayList(String Vetor);
	
	public String DiagnosticoMaisProvavel(String instances[][],ArrayList<String> Possiveis_Diagnosticos);
	
}


