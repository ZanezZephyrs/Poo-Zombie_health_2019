package src.interfaces;

import java.util.ArrayList;

public interface IDoctor extends IEnquirer, IResponderReceptacle, ITableProducerReceptacle {
    public ArrayList<String> getDiagnosis();
    public ArrayList<String> getConversa();
    public ArrayList<String> getPersonagens();
}