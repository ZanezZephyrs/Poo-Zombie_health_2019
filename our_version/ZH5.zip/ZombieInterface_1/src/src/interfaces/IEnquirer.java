package src.interfaces;

public interface IEnquirer {
	public void startInterview();
}
