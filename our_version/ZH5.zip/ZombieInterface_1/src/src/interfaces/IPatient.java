package src.interfaces;

public interface IPatient extends IResponder, ITableProducerReceptacle {
}
