package src.interfaces;

public interface IResponderReceptacle {
	public void connect(IResponder responder);
}
