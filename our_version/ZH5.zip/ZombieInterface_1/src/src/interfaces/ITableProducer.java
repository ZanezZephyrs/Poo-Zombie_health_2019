package src.interfaces;

public interface ITableProducer {
	  String[] requestAttributes();
	  String[][] requestInstances();
}