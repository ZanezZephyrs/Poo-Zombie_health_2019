package src.interfaces;

public interface ITableProducerReceptacle {
	  public void connect(ITableProducer producer);
	}